import React, { useState } from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

const LogApplication = () => {
  const [containerName, setContainerName] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [logs, setLogs] = useState([]);
  const [filteredLogs, setFilteredLogs] = useState([]);

  const handleShowLogs = () => {
    // Ensure both start and end dates are provided
    if (!startDate || !endDate) {
      alert("Please enter valid start and end dates.");
      return;
    }
  
    // Define the URL for your API endpoint
    const apiUrl = "http://example.com/api/logs"; // Replace with your API endpoint
  
    // Prepare the request body with the user's input
    const requestBody = {
      containerName,
      startDate,
      endDate,
    };
  
    // Send a POST request to the server
    fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestBody),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json();
      })
      .then((data) => {
        // Update the logs and filteredLogs state variables with the received data
        setLogs(data); // Assuming the response is an array of log objects
        setFilteredLogs(data); // Initially, show all logs
  
        // Optionally, you can add additional filtering logic here
        // Example: Filter logs based on date range
        const filteredLogs = data.filter((log) => {
          const logDate = new Date(log.timestamp);
          return logDate >= new Date(startDate) && logDate <= new Date(endDate);
        });
  
        setFilteredLogs(filteredLogs);
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  };
  

  return (
    <div>
      <h1>Log Application</h1>
      <form>
        <TextField
          label="Container Name"
          value={containerName}
          onChange={(e) => setContainerName(e.target.value)}
          required
        />
        <br />
        <br />
        <TextField
          label="Start Date"
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
          required
        />
        <br />
        <br />
        <TextField
          label="End Date"
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
          required
        />
        <br />
        <br />
        <Button variant="contained" onClick={handleShowLogs}>
          Show Logs
        </Button>
      </form>
      <div className="tab-data">
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell className="container-name-cell">Container Name</TableCell>
                <TableCell className="message-cell">Message</TableCell>
                <TableCell className="timestamp-cell">Timestamp</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredLogs.map((log, index) => (
                <TableRow key={index}>
                  <TableCell>{log.container_name}</TableCell>
                  <TableCell>{log.message}</TableCell>
                  <TableCell>{log.timestamp}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </div>
    </div>
  );
};

export default LogApplication;
