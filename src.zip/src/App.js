// import logo from './logo.svg';
import './App.css';
import MuiTable from './Table/MuiTable';

function App() {
  return (
    <div className="App">
      <MuiTable/>
    </div>
  );
}

export default App;
