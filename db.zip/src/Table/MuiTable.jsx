import React from "react";
import Paper from "@mui/material/Paper";


import {
    Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
} from "@mui/material";
import { useState } from "react";
import { useEffect } from "react";
import TextField from "@mui/material/TextField";
const MuiTable = () => {
  const columns = [

    { id: "container_name", name: "containername" },
    { id: "message", name: "message" },
    { id: "timestamp", name: "Time" },
  ];

  const handleChangepage=(event,newpage)=>{
    setpagechange(newpage)
  }

  const handleRowsPerPage=(event)=>{
    setrowsperpage(+event.target.value)
    setpagechange(0)
  }
  const [rows, setrowchange] = useState([]);
  const [page, setpagechange] = useState(0);
  const [rowperpage, setrowsperpage] = useState(100000);

  useEffect(() => {
    fetch("http://127.0.0.1:5000/send_data")
      .then((res) => {
        return res.json();
      })
      .then((res) => {
        setrowchange(res);
      })

      .catch((e) => {
        console.log(e.message);
      });
  }, []);
  return (
    <div style={{ textAlign: "center",marginTop:"2%" }}>
      
      <Box>
      <TextField
          id="standard-basic"
          label="username"
          variant="outlined"
          placeholder="username"
          required
          sx={{marginBottom:"5px"}}
        />
           <TextField
          id="standard-basic"
          label="username"
          variant="outlined"
          placeholder="username"
          required
          sx={{marginBottom:"5px"}}
        />
           <TextField
          id="standard-basic"
          label="username"
          variant="outlined"
          placeholder="username"
          required
          sx={{marginBottom:"5px"}}
        />
        
      <Paper sx={{ width: "90%", marginLeft: "5%" }}>
      
        <TableContainer sx={{maxHeight:450}}>
          <Table>
            <TableHead>
              <TableRow>
                {columns.map((column) => {
                  return (
                    <>
                      <TableCell style={{width:"20%",backgroundColor:"black",color:"white"}} key={column.id}>{column.name}</TableCell>
                    </>
                  );
                })}
              </TableRow>
            </TableHead>
            <TableBody>
            {rows &&rows.flat()
            .slice(page*rowperpage,page*rowperpage+rowperpage).map((row,i)=>{

                return(
                    <TableRow key={i}>
                        {columns && columns.map((column,i)=>{
                            let value = row[column.id]
                            return(
                                <TableCell key={value} style={{width:"30%"}}>
                                    {value}
                                </TableCell>
                            )
                        })}
                    </TableRow>
                )
            })}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
        rowsPerPageOptions={[100,100,100]}
        page={page}
        count={rows.length}
        rowsPerPage={rowperpage}
        component='div'
        onPageChange={handleChangepage}
        onRowsPerPageChange={handleRowsPerPage}
        >

        </TablePagination>
      </Paper>
      </Box>
    </div>
  );
};

export default MuiTable;
